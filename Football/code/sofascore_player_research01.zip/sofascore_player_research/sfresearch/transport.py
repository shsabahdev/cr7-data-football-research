"""HTTP transport.

Sofascore blocks plain HTTP clients at the TLS-fingerprint level, so the real
transport uses curl_cffi to present a Chrome fingerprint (the same approach as
pysofascore / scrapling). Tests inject a fake transport instead.
"""
from __future__ import annotations

from typing import Protocol

BASE = "https://api.sofascore.com/api/v1"


class Transport(Protocol):
    def get(self, path: str) -> tuple[int, dict | None]:
        """Return (http_status, parsed_json_or_None). Status 0 = network error."""


class CurlTransport:
    def __init__(self, impersonate: str = "chrome", timeout: int = 30):
        try:
            from curl_cffi import requests as curl_requests
        except ImportError as exc:  # pragma: no cover
            raise SystemExit(
                "Missing dependency. Run: pip install -r requirements.txt"
            ) from exc
        self._session = curl_requests.Session(impersonate=impersonate, timeout=timeout)

    def get(self, path: str) -> tuple[int, dict | None]:
        try:
            resp = self._session.get(
                BASE + path,
                headers={
                    "Accept": "application/json",
                    "Referer": "https://www.sofascore.com/",
                },
            )
        except Exception:
            return 0, None
        try:
            data = resp.json()
        except Exception:
            data = None
        return resp.status_code, data
